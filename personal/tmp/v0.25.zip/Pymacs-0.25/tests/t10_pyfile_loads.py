# -*- coding: utf-8 -*-

# Checking if Pymacs.py loads.

def test_1():
    import setup
